import UIKit

struct Engine {
    var v6 = 6
    var v8 = 8
}

let Engine2 = Engine()

print("The versions of v6 is \(Engine2.v6)")
